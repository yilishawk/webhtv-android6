/*
 * Copyright (C) 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.exoplayer.source.ads;

import static com.google.common.base.Preconditions.checkState;

import androidx.annotation.VisibleForTesting;
import androidx.media3.common.AdPlaybackState;
import androidx.media3.common.C;
import androidx.media3.common.Timeline;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.exoplayer.source.ForwardingTimeline;

/**
 * A custom {@link Timeline} for sources that have {@link AdPlaybackState} split among multiple
 * periods.
 *
 * <p>For each period a modified {@link AdPlaybackState} is created:
 *
 * <ul>
 *   <li>Ad group time is offset relative to period start time
 *   <li>Post-roll ad group is kept only for last period
 *   <li>Ad group count and indices are kept unchanged
 * </ul>
 */
@VisibleForTesting(otherwise = VisibleForTesting.PACKAGE_PRIVATE)
@UnstableApi
public final class AdTimeline extends ForwardingTimeline {

  private final AdPlaybackState[] adPlaybackStates;

  /**
   * Creates a new timeline alongside which ads will be played.
   *
   * @param contentTimeline The timeline of the content alongside which ads will be played.
   * @param adPlaybackState The state of the media's ads. The ad group times in this state must be
   *     relative to the start of the window (i.e. timeUs = 0 corresponds to the start of the
   *     window).
   */
  public AdTimeline(Timeline contentTimeline, AdPlaybackState adPlaybackState) {
    super(contentTimeline);
    int periodCount = contentTimeline.getPeriodCount();
    checkState(contentTimeline.getWindowCount() == 1);
    this.adPlaybackStates = new AdPlaybackState[periodCount];

    Timeline.Period period = new Timeline.Period();
    for (int periodIndex = 0; periodIndex < periodCount; periodIndex++) {
      timeline.getPeriod(periodIndex, period);
      adPlaybackStates[periodIndex] =
          forPeriod(
              adPlaybackState,
              period.positionInWindowUs,
              period.durationUs,
              /* isLastPeriod= */ periodIndex == periodCount - 1);
    }
  }

  @Override
  public Period getPeriod(int periodIndex, Period period, boolean setIds) {
    timeline.getPeriod(periodIndex, period, setIds);
    long durationUs =
        period.durationUs == C.TIME_UNSET
            ? adPlaybackStates[periodIndex].contentDurationUs
            : period.durationUs;
    period.set(
        period.id,
        period.uid,
        period.windowIndex,
        durationUs,
        period.getPositionInWindowUs(),
        adPlaybackStates[periodIndex],
        period.isPlaceholder);
    return period;
  }

  private AdPlaybackState forPeriod(
      AdPlaybackState adPlaybackState,
      long periodStartOffsetUs,
      long periodDurationUs,
      boolean isLastPeriod) {
    if (periodStartOffsetUs == 0 && isLastPeriod) {
      long contentDurationUs =
          periodDurationUs == C.TIME_UNSET ? adPlaybackState.contentDurationUs : periodDurationUs;
      return adPlaybackState.withContentDurationUs(contentDurationUs);
    }
    long contentDurationUs = periodDurationUs;
    if (contentDurationUs == C.TIME_UNSET) {
      contentDurationUs =
          isLastPeriod && adPlaybackState.contentDurationUs != C.TIME_UNSET
              ? adPlaybackState.contentDurationUs - periodStartOffsetUs
              : C.TIME_UNSET;
    }
    adPlaybackState = adPlaybackState.withContentDurationUs(contentDurationUs);

    for (int adGroupIndex = 0; adGroupIndex < adPlaybackState.adGroupCount; adGroupIndex++) {
      long adGroupTimeUs = adPlaybackState.getAdGroup(adGroupIndex).timeUs;
      if (adGroupTimeUs == C.TIME_END_OF_SOURCE) {
        if (!isLastPeriod) {
          adPlaybackState = adPlaybackState.withSkippedAdGroup(adGroupIndex);
        }
      } else {
        adPlaybackState =
            adPlaybackState.withAdGroupTimeUs(adGroupIndex, adGroupTimeUs - periodStartOffsetUs);
      }
    }
    return adPlaybackState;
  }
}
